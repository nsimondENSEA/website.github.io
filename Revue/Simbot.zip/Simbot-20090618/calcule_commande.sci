function [Commande] = calcule_commande(Robot)
// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// determination des rapports cycliques en fonction des quelques positions 
// possibles de capteurs eclaires : sous-echantillonnage des enveloppes des 
// lois de commande
//-----------------------------------------------------------------------------

if(isequal(Robot.Commande,zeros(2,Robot.nbr_sensors)))
    if(Robot.camera)  then
        Ind = 1:Robot.nbr_sensors;
    else
        Ind = int((Robot.Sensors(1,:)/Robot.largeur+.5)*size(Robot.alpha,2))+1;
    end
    Commande(1,:)   = Robot.conv(1)*Robot.alpha(1,Ind);
    Commande(2,:)   = Robot.conv(2)*Robot.alpha(2,Ind);
//    Commande(3,:)   = [.5, .5]*Commande([1,2],:);
//    Commande(4,:)   = atan([-1, 1]*Commande([1,2],:), Robot.largeur*ones(1,Robot.nbr_sensors));
end;

endfunction

