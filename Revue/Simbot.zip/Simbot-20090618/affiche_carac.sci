// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// affiche les caracteristiques statiques du robot
//-----------------------------------------------------------------------------
exec (TCL_GetVar("path_robot"));      // structure Robot
exec (TCL_GetVar("path_piste"));      // structure Piste
exec (TCL_GetVar("path_strategie"));  // structure Pose et Robot

if(isequal(Robot.Commande(:,1),[0;0]))  then
    if(~isdef('calcule_commande'))  then
        getf('calcule_commande.sci');
    end;
    Robot.Commande = calcule_commande(Robot);
end;

scf(2);
h               = gcf();
h.background    = Couleur.fond;
h.figure_name   = 'Caracteristiques statiques';
h.figure_size   = [900, 506];

if(Robot.Sensors(1,1) > -Robot.largeur/2) then
    xmin    = -Robot.largeur/2-5;
    xmax    = Robot.largeur/2+5;
else
    xmin    = Robot.Sensors(1,1)-5;
    xmax    = Robot.Sensors(1,Robot.nbr_sensors)+5;
end;

///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// Affichage du robot et de ses capteurs en position initiale
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////
subplot(221);
a                   = get("current_axes");
a.tight_limits      = "on";
a.data_bounds       = [0,0; Piste.bord_x,Piste.bord_y];
a.axes_bounds       = [0, 0, .52, 1];

a.background        = Couleur.plateau;
a.title.font_size   = 3;
a.x_label.font_size = 3;
a.y_label.font_size = 3;
a.y_label.font_angle= 0;
a.y_label.position  = [-Piste.bord_x/6,.47*Piste.bord_y];
xtitle('Piste d''essai virtuelle','x [cm]',['y';'[cm]']);
xgrid;
plot(Piste.coord(1,:),Piste.coord(2,:), 'thickness',3);
a.children.children.foreground = Couleur.piste;

Origin      = Piste.Init;
c           = cos(Pose.orient(1));
s           = sin(Pose.orient(1));
Rot         = [c, -s;...
               s,  c];
Mat         = [[Rot; 0,0] Origin];
Chassis     = Mat*Robot.Chassis;
Sensors     = Mat*Robot.Sensors;
xfpoly(Chassis(1,:),Chassis(2,:),Couleur.robot);
plot(Sensors(1,:),Sensors(2,:), '.', 'marksize',3);
plot(Sensors(1,:),Sensors(2,:), '.', 'thickness',2);
a.children.children(1).mark_size        = 3;
a.children.children(1).mark_foreground  = Couleur.capteur;

chaine = msprintf("duree : %5d",Piste.simu_time);
xstring(.65*Piste.bord_x,0, chaine);
a.children(1).font_foreground = Couleur.fond;
a.children(1).font_size = 4;
chaine = msprintf("Ts : %3d",Robot.Ts);
xstring(.04*Piste.bord_x,.94*Piste.bord_y, chaine);
a.children(1).font_foreground = Couleur.fond;
a.children(1).font_size = 4;

///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// Affichage de la reponse du microprocesseur
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////
subplot(222);
b                   = get("current_axes");
b.tight_limits      = "on";
[val,Coord]         = min(Robot.Commande);
if(val<0)
  minimum = round(val/Robot.conv(Coord(2))*100);
else
  minimum = 0;
end;
b.data_bounds       = [xmin, minimum-5;...
                       xmax, 105];
b.grid              = [1,1];
b.title.font_size   = 3;
b.x_label.font_size = 3;
b.y_label.font_size = 3;
b.y_label.font_angle= 0;

if(Robot.camera)  then
    pas         = Robot.Sensors(1,2)-Robot.Sensors(1,1);
    Abscisses   = Robot.Sensors(1,:);
else,
    pas         = .1;               // pas de discretisation [cm]
    Abscisses   = -Robot.largeur/2:pas:Robot.largeur/2;
end;

if(Robot.camera)
    plot(Abscisses,100*Robot.alpha(1,:), 'thickness',2);
    plot(Abscisses,100*Robot.alpha(2,:), 'thickness',2);
    b.children.children(1).foreground   = Couleur.droit;
    b.children.children(2).foreground   = Couleur.gauche;
else
    plot(Abscisses,100*Robot.alpha(1,:), 'thickness',1);
    plot(Abscisses,100*Robot.alpha(2,:), 'thickness',1);
    b.children.children(1).foreground   = Couleur.droit;
    b.children.children(2).foreground   = Couleur.gauche;
    plot(Robot.Sensors(1,:),100*Robot.Commande(1,:)/Robot.conv(1), '.');
    plot(Robot.Sensors(1,:),100*Robot.Commande(2,:)/Robot.conv(2), '.');
    b.children(1).children.mark_foreground = Couleur.droit;
    b.children(2).children.mark_foreground = Couleur.gauche;
end;

chaine = msprintf("tau  : %3d",Robot.tau(1));
xstring(xmin+(xmax-xmin)*.05,57, chaine);
b.children(1).font_foreground = Couleur.gauche;
b.children(1).font_size = 4;
chaine = msprintf("conv : %1.3f",Robot.conv(1));
xstring(xmin+(xmax-xmin)*.05,37, chaine);
b.children(1).font_foreground = Couleur.gauche;
b.children(1).font_size = 4;
chaine = msprintf("tau  : %3d",Robot.tau(2));
xstring(xmin+(xmax-xmin)*.7,57, chaine);
b.children(1).font_foreground = Couleur.droit;
b.children(1).font_size = 4;
chaine = msprintf("conv : %1.3f",Robot.conv(2));
xstring(xmin+(xmax-xmin)*.7,37, chaine);
b.children(1).font_foreground = Couleur.droit;
b.children(1).font_size = 4;

//b.children.children(1).thickness = 2;
//b.children.children(2).thickness = 2;
b.y_label.position  = [xmin-(xmax-xmin)/5,b.data_bounds(1,2)+.24*[-1,1]*b.data_bounds(:,2)];
xtitle("Evolution des rapports cycliques en fonction de la distance a l''axe",'',['vitesse'; 'relative'; '[%]']);

///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// Affichage de la piste et de la position du robot au depart
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////
subplot(224);
ymin	= min(Robot.Sensors(2,:));  // ordonnee du capteur le plus bas
ymax	= max(Robot.Sensors(2,:));  // ordonnee du capteur le plus haut
if(ymin>-Robot.longueur/2)  then ymin = -Robot.longueur/2;   end;
if(ymax<Robot.longueur/2)   then ymax = Robot.longueur/2;    end;
if(ymin == ymax)            then ymin = -Robot.longueur/2;   end;

c                   = get("current_axes");
c.tight_limits      = "on";
c.data_bounds       = [Abscisses(1)-5, ymin-5;...
                       Abscisses(length(Abscisses))+5, ymax+5];
c.axes_bounds       = [.5, .48, .5, .5];
c.background        = Couleur.plateau;
c.title.font_size   = 3;
c.x_label.font_size = 3;
c.y_label.font_size = 3;
c.y_label.font_angle= 0;
c.y_label.position  = [xmin-(xmax-xmin)/5,ymin+(ymax-ymin)*.45];
xtitle ("Disposition des capteurs sur le robot",'x [cm]',['y';'[cm]']);
xgrid;

xfpoly(Robot.Chassis(1,:), Robot.Chassis(2,:), Couleur.robot);
plot(Robot.Sensors(1,:), Robot.Sensors(2,:), '.', 'marksize',4);
c.children.children(1).mark_foreground = Couleur.capteur;

clear pas Abscisses Chassis Mat Sensors;
