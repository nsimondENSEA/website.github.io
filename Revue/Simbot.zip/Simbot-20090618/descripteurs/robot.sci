// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// Caracteristiques geometriques du robot etudie (ligne de capteur).
//-----------------------------------------------------------------------------

// l'origine du repère est le centre de gravite du chassis, 
// les mesures sont exprimees en cm
// les durees en ms

largeur     = 30;
longueur    = 40;
nbr_sensors = 8;                    

// caracteristiques geometriques du chassis : largeur, longueur, Chassis
// disposition relative des capteurs sur le chassis : nbr_sensors, Sensors, Commande
// caracteristiques electro-mecaniques des moteurs et reducteurs : tau, conv, alpha

// structure synthetique Robot
Robot = struct('camera', 0,...          // booleen précisant l'usage d'une camera ou de photo-transistors
               'largeur', largeur,...
               'longueur', longueur,...
               'Ts', 20,...             // duree entiere de la période d'echantillonnage
               'Chassis', [-largeur/2, largeur/2, largeur/2, -largeur/2; longueur/2, longueur/2, -longueur/2, -longueur/2; 1, 1, 1, 1],...
               'nbr_sensors', nbr_sensors,...
               'Sensors', [-7:14/(nbr_sensors-1):7; 18*ones(1,nbr_sensors); ones(1,nbr_sensors)],...
               'Commande', zeros(2,nbr_sensors),... // rapports cycliques discretises en fonction des nbr_sensors configurations possibles
               'tau', [150, 150],...    // Constante de temps du moteur gauche puis droit
               'conv', [.1, .1],...     // 3000 tours minutes, D=5 cm 3 m/s retenue,  7.8 m/s en theorie ! ici unite = [cm/ms]
               'alpha', [0,0]);         // initialisation de la commande theorique non discretisee

clear largeur longueur nbr_sensors;
