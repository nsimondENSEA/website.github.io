// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// Calcul des reponses du microprocesseur : determination des rapports cycliques
// en fonction des capteurs eclaires
//-----------------------------------------------------------------------------

// les couleurs
Couleur = struct('capteur',6,...    // rose
                 'consigneg',19,... // rouge fonce
                 'consigned',13,..  // vert fonce
                 'droit',3,...      // vert
                 'fond',32,...      // jaune fonce
                 'gauche',5,...     // rouge
                 'piste',8,...      // blanc
                 'plateau',9,...    // bleu fonce
                 'robot',12);       // bleu ciel

// discretisation de la commande alpha en fonction de la position relative de la ligne blanche
if(Robot.camera)  then
    pas         = Robot.Sensors(1,2)-Robot.Sensors(1,1);
    Abscisses   = Robot.Sensors(1,:);
else,
    pas         = .1;               // pas de discretisation [cm]
    Abscisses   = -Robot.largeur/2:pas:Robot.largeur/2;
end;
nbr_ech = length(Abscisses);

// commande du moteur gauche
// >> commenter le code a partir d'ici, 
x1          = -7;
x2          = 5;
y1          = -.2;
y2          = 1;
ind1        = find( (Abscisses>x1-pas/2) & (Abscisses<x1+pas/2) );
ind2        = find( (Abscisses>x2-pas/2) & (Abscisses<x2+pas/2) );
x1          = Abscisses(ind1);
x2          = Abscisses(ind2);
alpha_gauche= [y1*ones(1,ind1), (y2-y1)/(x2-x1)*(Abscisses(ind1+1:ind2)-x1)+y1, y2*ones(1,nbr_ech-ind2)];
// >> jusque la, puis le remplacer par le votre 
// >> ne pas oublier d'affecter la variable alpha_gauche ...

// commande du moteur droit
// >> commenter le code a partir d'ici, 
x1          = -5;
x2          = 7;
y1          = 1;
y2          = -.2;
ind1        = find( (Abscisses>x1-pas/2) & (Abscisses<x1+pas/2) );
ind2        = find( (Abscisses>x2-pas/2) & (Abscisses<x2+pas/2) );
x1          = Abscisses(ind1);
x2          = Abscisses(ind2);
alpha_droite= [y1*ones(1,ind1), (y2-y1)/(x2-x1)*(Abscisses(ind1+1:ind2)-x1)+y1, y2*ones(1,nbr_ech-ind2)];
// >> jusque la, puis le remplacer par le votre 
// >> ne pas oublier d'affecter la variable alpha_droite ...

Robot.alpha = [alpha_gauche;alpha_droite];

if(Robot.camera)    then
    nbr_sensors = 10;   // 5 possiblites d'adjacences avec la piste
else
    nbr_sensors = Robot.nbr_sensors;
end;

Pose= struct('it', 1,...
             'nbr_sensors', zeros(1,Piste.simu_time),...    // nombre de capteurs eclaires
             'sensor', zeros(1,Piste.simu_time),...         // position relative de la ligne
             'Capteurs', zeros(nbr_sensors,Piste.simu_time),...// numeros des capteurs eclaires
             'dist', zeros(1,Piste.simu_time),...           // position absolue de la ligne
             'cons', zeros(2,Piste.simu_time),...           // consigne de la vitesse souhaitee
             'speed', zeros(2,Piste.simu_time),...          // vitesse instantannee
             'trans', zeros(1,Piste.simu_time),...          // valeur de la translation selon l'axe du robot
             'angle', zeros(1,Piste.simu_time),...          // valeur de l'angle de rotation entre 2 echantillons
             'orient', zeros(1,Piste.simu_time),...         // orientation absolue du robot par rapport au plan de la piste
             'Location', [zeros(2,Piste.simu_time);ones(1,Piste.simu_time)]); // coordonnes absolues du centre du robot sur la piste

clear x1 x2 y1 y2 ind1 ind2 alpha_gauche alpha_droite nbr_ech nbr_sensors pas Abscisses;

