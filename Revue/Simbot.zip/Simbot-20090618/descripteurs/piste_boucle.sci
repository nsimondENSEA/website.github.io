// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// Detail de la trajectoire de test : ligne droite verticale, 1/4 de tour a droite, 
//  ligne droite, 1/2 tour, ligne droite
//-----------------------------------------------------------------------------

// 1/4 de tour : 47 cm de courbure (=47 points) a  R=30 cm
// les distances sont exprimees en cm
// les durees sont exprimees en ms

// coordonnees des points de la piste
Theta           = [%pi/(2*46):%pi/(2*46):%pi/2];
trajectoire_x   = [200*ones(1,180),...              // (200;1)  -> (200;180)
                   201:220,...                      // (201;180)-> (220;180)
                   200,...                          // apres l'aller, le retour
                   200*ones(1,50),...               // (200;181)-> (200;230)
                   30*cos(%pi-Theta)+230,...        // (200;230)-> (230;200)
                   30*cos(%pi/2-Theta)+230,...      // (230;200)-> (260;230)
                   30*cos(-Theta)+230,...           // (260;230)-> (230;200)
                   229:-1:100,...                   // (229;200)-> (101;200)
                   30*cos(%pi/2+Theta)+100,...      // (100;200)-> (70;170)
                   30*cos(%pi+Theta)+100,...        // (70;170) -> (100;140)
                   30*cos(%pi/2-Theta)+100,...      // (100;140)-> (130;110)
                   30*cos(-Theta)+100,...           // (130;110)-> (100;80)
                   99:-1:1];                        // (99;80)  -> (1;80)
                   
trajectoire_y   = [1:180,...                        // (200;1)  -> (200;180)
                   180*ones(1,20),...               // (201;180)-> (220;180)
                   180,...                          // apres l'aller, le retour
                   181:230,...                      // (200;181)-> (200;230)
                   30*sin(%pi-Theta)+230,...        // (200;230)-> (230;200)
                   30*sin(%pi/2-Theta)+230,...      // (230;200)-> (260;230)
                   30*sin(-Theta)+230,...           // (260;230)-> (230;200)
                   200*ones(1,130),...              // (229;200)-> (101;200)        
                   30*sin(%pi/2+Theta)+170,...      // (100;200)-> (70;170)
                   30*sin(%pi+Theta)+170,...        // (70;170) -> (100;140)
                   30*sin(%pi/2-Theta)+110,...      // (100;140)-> (130;110)
                   30*sin(-Theta)+110,...           // (130;110)-> (100;80)
                   80*ones(1,99)];                  // (99;80)  -> (1;80)                   
                   
// structure dediee a la piste suivie par le robot
Piste = struct('bord_x', 300,...                    // limite verticale de la piste
               'bord_y', 300,...                    // limite horizontale de la piste
               'coord', [trajectoire_x; trajectoire_y; ones(1,length(trajectoire_x))],...
               'length', length(trajectoire_x),...   // nombre de points de la piste
               'largeur', 2,...                     // largeur de la piste              
               'Init', [198;0;1],...                // position initiale du robot               
               'simu_time', 8000);                  // duree maximale de la simulation

clear Theta trajectoire_x trajectoire_y;
