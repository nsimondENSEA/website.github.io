// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// Detail de la trajectoire de test : ligne droite verticale, tournant a droite, 
//-----------------------------------------------------------------------------

// 2 metres (precision 1cm)
// Courbe : 47 cm de courbure (=47 points) a  R=30cm
// les distances sont exprimees en cm
// les durees sont exprimees en ms

// coordonnees des points de la piste
Theta           = [%pi:-%pi/(2*46):%pi/2];
trajectoire_x   = [100*ones(1,170),...
                   30*cos(Theta)+130,...
                   131:300];
trajectoire_y   = [1:170,...
                   30*sin(Theta)+170,...
                   200*ones(1,170)];

// structure dediee a la piste suivie par le robot
Piste = struct('coord', [trajectoire_x; trajectoire_y; ones(1,length(trajectoire_x))],...
               'length', length(trajectoire_x),...  // nombre de points de la piste
               'largeur', 2,...                     // largeur de la piste
               'bord_x', 300,...                    // limite verticale de la piste
               'bord_y', 300,...                    // limite horizontale de la piste
               'Init', [102;0;1],...                // position initiale du robot               
               'simu_time', 8000);                  // duree maximale de la simulation
             
clear Theta trajectoire_x trajectoire_y;
