// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// affichage de l'evolution de la trajectoire du robot et de ses variables internes
//-----------------------------------------------------------------------------
function []=affiche_simulation(Piste,Pose,Robot,Couleur,Mat)

disp('Initialisation de l''affichage');
if it < Piste.simu_time then 
    Piste.simu_time = it;
end;

scf(1);
h               = gcf();
h.pixmap        = "on";
h.background    = Couleur.fond;
h.figure_name   = 'Trajectographie du robot';
h.figure_size   = [1024 570];

N   = 1:Piste.simu_time;
it  = 1;

///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// initialisation de la fenetre graphique
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////
// suivi du robot
subplot(321);
a                   = get("current_axes");
a.axes_visible      = "on"; 
a.axes_bounds       = [0, 0, .55, 1];
a.data_bounds       = [0,0;Piste.bord_x,Piste.bord_y];
a.tight_limits      = "on";
a.background        = Couleur.plateau;
a.title.font_size   = 3;
a.x_label.font_size = 3;
a.y_label.font_size = 3;
a.y_label.font_angle= 0;
xtitle('Piste d''essai virtuelle','x [cm]',['y';'[cm]']);

plot(Piste.coord(1,:),Piste.coord(2,:), 'thickness',4);
a.children.children(1).foreground = Couleur.piste;

Chassis     = Mat(:,:,it)*Robot.Chassis;
xfpoly(Chassis(1,:), Chassis(2,:), Couleur.robot);
idchassis	  = gce();

// petite astuce pour accelerer l'affichage dans le cas de la camera : 
//  trace la ligne entre les 2 extremites de la ligne image
if(Robot.camera)    then
    Sensors = Mat(:,:,it)*Robot.Sensors(:,Nsensors);
    plot(Sensors(1,:),Sensors(2,:), 'thickness',3);
    a.children.children(1).foreground = Couleur.capteur;
else    
    Sensors = Mat(:,:,it)*Robot.Sensors;
    plot(Sensors(1,:),Sensors(2,:), '.', 'thickness',2);
    a.children.children(1).mark_size        = 3;
    a.children.children(1).mark_foreground  = Couleur.capteur;
end;
idsensors   = gce();
Moteurs     = [Chassis(:,[1,4])*[.5;.5],Chassis(:,[2,3])*[.5;.5]];
plot(Moteurs(1,1),Moteurs(2,1),'r.', 'marksize',3);
idMoteurG   = gce();
plot(Moteurs(1,2),Moteurs(2,2),'g.', 'marksize',3);
idMoteurD   = gce();

chaine = msprintf("it : %6d",0);    // position initiale
xstring(.75*Piste.bord_x,0, chaine);
a.children(1).font_foreground = Couleur.fond;
a.children(1).font_size = 5;
idnum = gce();

// capteurs eclaires par la piste
subplot(322);
b                   = get("current_axes");
b.axes_bounds       = [.51, 0, .55, .31];
b.tight_limits      = "on";
b.data_bounds       = [0,0;Piste.simu_time,Robot.nbr_sensors+1];
b.auto_clear        = "off";
b.auto_scale        = "off";
b.grid;
b.title.font_size   = 3;
b.x_label.font_size = 3;
b.y_label.font_size = 3;
b.y_label.font_angle= 0;
b.y_label.position  = [-b.data_bounds(2,1)/5,b.data_bounds(1,2)+.4*[-1,1]*b.data_bounds(:,2)];
xtitle('Capteurs eclaires par la piste','','capteur');

if(Robot.camera)    then
//ICI : le plot est-il adapté dans ce cas là : affichage de plusieurs segments verticaux disjoints ???    
    plot([it,it],Pose.Capteurs([1,2],it)', 'b');
else    
   plot(it, Pose.Capteurs(1,it), 'b.', 'marksize',2);
end;
xgrid();

// position absolue de la piste detectee par le robot
subplot(324);
c                   = get("current_axes");
c.tight_limits      = "on";
c.axes_bounds       = [.51, .33, .55, .31];
c.data_bounds       = [0,min(Robot.Sensors(1,:))-1;Piste.simu_time,max(Robot.Sensors(1,:))+1];
c.auto_clear        = "off";
c.auto_scale        = "off";
c.title.font_size   = 3;
c.x_label.font_size = 3;
c.y_label.font_size = 3;
c.y_label.font_angle= 0;
c.y_label.position  = [-c.data_bounds(2,1)/5,c.data_bounds(1,2)+.34*[-1,1]*c.data_bounds(:,2)];
xtitle('Position absolue de la piste','',['distance';'[cm]']);

plot(it,Pose.dist(it),'b');
xgrid();

// vitesses des moteurs
subplot(326);
d                   = get("current_axes");
d.tight_limits      = "on";
d.axes_bounds       = [.51, .66, .55, .31];
[val,Coord]         = min(Pose.cons);
if(val<0) then
  minimum = round(val/Robot.conv(Coord(1))*100);
else
  minimum = 0;
end;
d.data_bounds       = [0,minimum;Piste.simu_time,100];
d.auto_clear        = "off";
d.auto_scale        = "off";
d.title.font_size   = 3;
d.x_label.font_size = 3;
d.y_label.font_size = 3;
d.y_label.font_angle= 0;
d.y_label.position  = [-d.data_bounds(2,1)/5,d.data_bounds(1,2)+.24*[-1,1]*d.data_bounds(:,2)];
xtitle('Vitesses des moteurs','temps [ms]',['vitesse'; 'relative'; '[%]']);
Pose.cons(:,it) = [.5;.8];
plot(it,Pose.cons(1,it)/Robot.conv(1)*100,'r');
plot(it,Pose.cons(2,it)/Robot.conv(2)*100,'g');
plot(it,Pose.speed(1,it)/Robot.conv(1)*100,'r', 'marksize',2);
plot(it,Pose.speed(2,it)/Robot.conv(1)*100,'g', 'marksize',2);
d1  = d.children(4).children;
d2  = d.children(3).children;
d3  = d.children(2).children;
d4  = d.children(1).children;
d1.foreground       = Couleur.consigneg;
d2.foreground       = Couleur.consigned;
d1.polyline_style   = 6;
d2.polyline_style   = 6;
xgrid();

///////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// la boucle d'affichage
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////
disp('Affichage');
j       = 0;
winId   = progressionbar('Affichage en cours');
realtimeinit(.1);

for it = 2:20:Piste.simu_time,
    j = j+.01;
    realtime(3*j);
    progressionbar(winId);
 
    drawlater();
    Chassis    = Mat(:,:,it)*Robot.Chassis;
    Sensors    = Mat(:,:,it)*Robot.Sensors(:,Nsensors);
    Moteurs    = [Chassis(:,[1,4])*[.5;.5],Chassis(:,[2,3])*[.5;.5]];
    chaine     = msprintf("it : %6d",it-1);   // la position initiale est la n�1
    idchassis.data	= Chassis([1,2],:)';
    idsensors.children.data	= Sensors([1,2],:)';
    idnum.text = chaine;

    idMoteurG.children.data=[idMoteurG.children.data; Moteurs(1,1), Moteurs(2,1)];
    idMoteurD.children.data=[idMoteurD.children.data; Moteurs(1,2), Moteurs(2,2)];

    if(Robot.camera)    then
        for l = 1:Pose.nbr_sensors(it)
//ICI : cela bloque (normal)
//            b.children.children.data=[b.children.children.data; [it,it], Pose.Capteurs([2*l-1,2*l])'];
        end;    
    else
        for l = 1:Pose.nbr_sensors(it)
            b.children.children.data=[b.children.children.data; it, Pose.Capteurs(l,it)];
        end;
    end;
     
    c.children.children.data=[c.children.children.data;it,Pose.dist(it)];

    d1.data=[d1.data;it,Pose.cons(1,it)/Robot.conv(1)*100];
    d2.data=[d2.data;it,Pose.cons(2,it)/Robot.conv(2)*100];
    d3.data=[d3.data;it,Pose.speed(1,it)/Robot.conv(1)*100];
    d4.data=[d4.data;it,Pose.speed(2,it)/Robot.conv(1)*100];
 
    drawnow() ;
    show_pixmap();
end;
h.pixmap = 'off';

// informations supplementaires
//subplot(324);
moyenne = mean(abs(Pose.dist(N)));
sigma   = variance(Pose.dist(N));
chaine  = msprintf("|moy| = %2.2f",moyenne);
////ICI : je ne vois pas quel champ modifier 
//xstring(Piste.simu_time*.8, min(Robot.Sensors(1,:)), chaine);
//chaine  = msprintf("sigma = %2.2f",sigma);
////ICI
//xstring(Piste.simu_time*.8, min(Robot.Sensors(1,:))+.15*(max(Robot.Sensors(1,:))-min(Robot.Sensors(1,:))), chaine);
//c.children(1).font_foreground = Couleur.plateau;
//c.children(1).font_size = 3;
//pause
//c.children(2).font_foreground = Couleur.plateau;
//c.children(2).font_size = 3;

//subplot(326);
//chaine  = msprintf("Rconv = %2.2f cm/s",Robot.conv(2));
//xstring(Piste.simu_time*.7, 5, chaine);
//chaine  = msprintf("Lconv = %2.2f cm/s",Robot.conv(1));
//xstring(Piste.simu_time*.7, 20, chaine);
//d.children(1).font_foreground = 3;
//d.children(1).font_size = 3;
//d.children(2).font_foreground = 5;
//d.children(2).font_size = 3;
winclose(winId);
disp('Simulation terminee');
endfunction

