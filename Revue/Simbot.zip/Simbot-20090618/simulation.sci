// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// fonction principale 
//-----------------------------------------------------------------------------
clear();
xdel(winsid());

getf('supprime_doublons.sci');
getf('affiche_simulation.sci');
getf('calcule_commande.sci');

exec (TCL_GetVar("path_piste"));        // structure Piste
exec (TCL_GetVar("path_robot"));        // structure Pose et Robot
exec (TCL_GetVar("path_strategie"));    // structure Pose et Robot

disp('Initialisation');
// <<<<<<<<<<<<<<<<<<<<<<< initialisation des variables >>>>>>>>>>>>>>>>>>>>>>>
it                  = 1;
Pose.sensor(it)     = int(Robot.nbr_sensors/2); // capteur le plus proche de la piste
Pose.nbr_sensors(it)= 1;                        // nombre de capteurs eclaires
Pose.Location(:,it) = Piste.Init;               // coordonnees du centre du robot dans le repere de la piste
Pose.Capteurs(1,1)  = Pose.sensor(it);
if(Robot.camera)    then
    Pose.Capteurs(2,it) = Pose.sensor(it);
end;

// Commande : tableau de synthese des mouvements de rotation et translation 
//  pour chaque configuration de capteur valide
Robot.Commande  = calcule_commande(Robot);
if(Robot.camera)  then
    Nsensors= [1,Robot.nbr_sensors];
else
    Nsensors= 1:Robot.nbr_sensors;
end

// Mat : positions et orientations du robot dans le repere de la piste au cours du deplacement
c           = cos(Pose.orient(it));      
s           = sin(Pose.orient(it));
Trans       = zeros(3,1);                   // vecteur translation
Rot         = [c, -s;...                    // matrice de rotation
               s,  c];
Mat         = zeros(3,3,Piste.simu_time);   // matrice deplacement
Mat(:,:,it) = [[Rot;0,0],Pose.Location(:,it)];

// prise en compte de la constante de temps moteur pour le calcul des vitesses instantannees
ExpL = 1-exp(-(1:Robot.Ts)/Robot.tau(1));
ExpR = 1-exp(-(1:Robot.Ts)/Robot.tau(2));
Expo = [ExpL;ExpR];

disp('Calcul de la trajectoire');
// boucle de simulation
cmptr       = Robot.Ts;
Speed_fin   = [0;0];

for it=2:Piste.simu_time;   //it represente le temps en milliseconde
    Pose.it = it;
  
    //<<<<<<<<<< determination du capteur le plus proche de la piste >>>>>>>>>>
    //<<<<<<<<<<< a partir du (des) capteur(s) eclaires par la piste >>>>>>>>>> 
    if(cmptr == Robot.Ts) then       
        // Sensors : coordonnees des Pose.Capteurs dans le repere de la piste        
        cmptr   = 0;
        Sensors = Mat(:,:,it-1)*Robot.Sensors;
        
        //<<<<<<<<<<<<<< calcul des distances piste/Pose.Capteurs >>>>>>>>>>>>>
        if(Robot.camera)  then
            Milieu      = Sensors(:,Nsensors)*[.5;.5];
            Num_Piste   = find(abs(Piste.coord(2,:)-Milieu(2)) < Robot.balayage/2);
            if(length(Num_Piste) > Robot.balayage)    then
                Ind         = find(abs(Piste.coord(1,Num_Piste)-Milieu(1)) < Robot.balayage/2);
                Num_Piste   = Num_Piste(Ind);
            end;
        
            // calcul du pixel le + proche de la ligne dediee car trop long a l'execution
            // calcul des coordonnees de la droite Line qui porte les pixels pour calculer ensuite la distance 
            //  qui separe les points de la piste de la droite "pixels"          
            V       = Sensors(:,Nsensors)*[1;-1];
            V       = V/norm(V);
            Line    = [-V(2);V(1);0];
            Line(3) = -Line'*Sensors(:,1);
          
            // Num_Piste(Ind) : numero des points du chemin les + proche de la droite
            // inutile de calculer la racine carree de Dist2 pour determiner les pixels eclaires
            Dist_Piste  = Line'*Piste.coord(:,Num_Piste);
            Ind         = find(abs(Dist_Piste) < Piste.largeur);
            Diffx       = Sensors(1,:)'*ones(1,length(Ind)) - ones(Robot.nbr_sensors,1)*Piste.coord(1,Num_Piste(Ind));
            Diffy       = Sensors(2,:)'*ones(1,length(Ind)) - ones(Robot.nbr_sensors,1)*Piste.coord(2,Num_Piste(Ind));
            Dist2       = Diffx.*Diffx + Diffy.*Diffy; 
        else
            // calcul de la distance au carre qui separe la piste de chacun des capteurs
            // determination du capteur le plus proche de la piste
            // inutile de calculer la racine carree de Dist2 pour determiner le minimum
            Diffx       = Sensors(1,:)'*ones(1,Piste.length) - ones(Robot.nbr_sensors,1)*Piste.coord(1,:);
            Diffy       = Sensors(2,:)'*ones(1,Piste.length) - ones(Robot.nbr_sensors,1)*Piste.coord(2,:);
            Dist2       = Diffx.*Diffx + Diffy.*Diffy;
        end;
    
        // <<<<<<<<<<<<<<<< determination des capteurs eclaires >>>>>>>>>>>>>>>
        [Lig,Col]           = find(Dist2 < Piste.largeur*Piste.largeur);
        Lig                 = supprime_doublons(Lig);
        nlig                = length(Lig);
                
        if(nlig == 0)   then
            Pose.sensor(it)     = Pose.sensor(it-1);
            Pose.nbr_sensors(it)= Pose.nbr_sensors(it-1);
            Pose.Capteurs(:,it) = Pose.Capteurs(:,it-1);
        else
            if(Robot.camera)    then
                ind = 0;
                nc  = nlig;
                nlig=0;
                while(nc > 0)                    
                    Diff    = Lig(1:nc-1) - Lig(2:nc);
                    Col     = find(Diff ~= 1);
                    nlig    = nlig+1;
                    if(isempty(Col))    then
                        Pose.Capteurs(ind+[1,2],it)  = Lig([1,nc])';
                        Lig             = [];
                        nc              = 0;
                    else
                        Pose.Capteurs(ind+[1,2],it)  = Lig([1,Col(1)])';
                        Lig(1:Col(1))   = [];
                        nc              = nc-Col(1);
                    end;
                    ind = ind+2;
                end;
                Lig = int([.5,.5]*Pose.Capteurs([ind-1,ind],it));
            else
                Pose.Capteurs(1:nlig,it) = Lig';
            end;        
            Pose.nbr_sensors(it)= nlig;
            
            // selection du capteur eclaire le plus "proche" de la piste pour determiner la commande
            if(nlig > 1)    then
                [val,lig]       = min(abs(Lig-Pose.sensor(it-1)));
                Pose.sensor(it) = Lig(lig);
            elseif(nlig == 1)    then
                Pose.sensor(it) = Lig;
            else
                Pose.sensor(it) = Pose.sensor(it-1);
            end;
        end;
   
        //<<<<<<<<<<<<<< valeurs limite et initiale des vitesses >>>>>>>>>>>>>>
        Speed_init      = Pose.speed(:,it-1);
        Speed_fin       = Robot.Commande([1,2],Pose.sensor(it));
    else
        Pose.sensor(it)     = Pose.sensor(it-1);
        Pose.nbr_sensors(it)= Pose.nbr_sensors(it-1);
        if(Robot.camera)    then
            Pose.Capteurs(:,it)  = Pose.Capteurs(:,it-1);
        else
            Pose.Capteurs(1:nlig,it) = Pose.Capteurs(1:nlig,it-1);
        end;        
    end;
    cmptr = cmptr+1;

  //<<<<<<<<<<<<<<<<<< calcul de la vitesse de chaque moteur >>>>>>>>>>>>>>>>>>
  // calcul du vecteur vitesse speed de chaque moteur grace a 
  //    la linearisation du deplacement par pas de simulation Robot.Ts
  // estimation du vecteur translation Trans[0;dt;0] et mouvement 
  //    de rotation Rot de dtheta autour de la verticale
  if(Pose.sensor(it) > 0) then
    Pose.dist(it)   = Robot.Sensors(1,Pose.sensor(it));
    Pose.cons(:,it) = Speed_fin;
    Pose.speed(:,it)= Speed_init+(Speed_fin-Speed_init).*Expo(:,cmptr);
    dt              = [.5, .5]*Pose.speed(:,it);
    dtheta          = atan([-1, 1]*Pose.speed(:,it), Robot.largeur);
    
    // <<<<<<<<<<< calcul du deplacement >>>>>>>>>>>
    // calcul des deplacements elementaires
    // prise en compte de l'inertie du robot
    // calcl du deplacement Dep durant le pas temporel
    Pose.angle(it)      = dtheta;
    Pose.trans(it)      = dt;
    Pose.orient(it)     = Pose.orient(it-1)+dtheta;
    Trans(2)            = dt;
    c                   = cos(Pose.orient(it));
    s                   = sin(Pose.orient(it));
    Rot                 = [c, -s;...
                           s,  c];
    Dep                 = [Rot,[0;0];0 0 1]*Trans;
    Pose.Location(:,it) = Pose.Location(:,it-1)+Dep;    
    Mat(:,:,it)         = [[Rot;0,0],Pose.Location(:,it)];

  else
    disp('Robot hors-piste');
    break;
  end

  //<<<<<<<<<<<<<<<<<<<<<<<<< detection de l'arrivee >>>>>>>>>>>>>>>>>>>>>>>>>>
  if ((Pose.Location(1,it)>Piste.bord_x-10) | (Pose.Location(2,it)>Piste.bord_y-10) | (Pose.Location(1,it)<10) | (Pose.Location(2,it)<0)) then break; end;

end;

TCL_SetVar("temps",it);
TCL_SetVar("distance",mad(Pose.dist(1:it)));

affiche_simulation(Piste,Pose,Robot,Couleur,Mat);
