#! /usr/bin/wish

# GUI du simulateur de robot version 1.0
# By A. TAUVEL & N. SIMOND 2009
# Nécessite TCL /Tk et Scilab préalablement installés.

set path_piste "./descripteurs/piste.sci"
set path_robot "./descripteurs/robot.sci"
set path_strategie "./descripteurs/strategie.sci"
set temps "N/A"
set distance "N/A"

set type {
		{{Descripteurs} {.sci}}
		{{Tous} * }
		}  

	global path_piste
	global path_robot
	global path_strategie
	global temps
	global distance
	global fenetre

	toplevel .w
	wm title .w "GEII Sarcelles"
	frame .w.top -borderwidth 10 
	pack .w.top -fill x

	image create photo dossier -file ./images/dossier.gif 
	image create photo editeur -file ./images/editer.gif 

	frame .w.caracteristique

	frame .w.caracteristique.piste
	frame .w.caracteristique.robot
	frame .w.caracteristique.strategie
	frame .w.caracteristique.temps
	frame .w.caracteristique.distance
	frame .w.caracteristique.lance
	
	label .w.caracteristique.piste.etiqu -width 35 -justify right -text "Caract\u00E9ristique de la piste : "
	label .w.caracteristique.robot.etiqu -width 35 -justify right -text "Caract\u00E9ristique m\u00E9canique du robot : "
	label .w.caracteristique.strategie.etiqu -width 35 -justify right -text "Strat\u00E9gie de commande du robot : "


	label .w.caracteristique.piste.label -relief sunken -width 60 -justify left -textvariable path_piste
	label .w.caracteristique.robot.label -relief sunken -width 60 -justify left -textvariable path_robot
	label .w.caracteristique.strategie.label -relief sunken -width 60 -justify left -textvariable path_strategie

	
	button .w.caracteristique.piste.ouvrir -image dossier -command {set path_piste_n [tk_getOpenFile -title "Choix de la piste" -initialdir "./descripteurs" -filetypes $type]
		if {[string length $path_piste_n]} {
		set path_piste $path_piste_n}} 
	button .w.caracteristique.robot.ouvrir -image dossier -command {set path_robot_n [tk_getOpenFile -title "Choix du robot" -initialdir "./descripteurs" -filetypes $type]
		if {[string length $path_robot_n]} {
		set path_robot $path_robot_n}} 
	button .w.caracteristique.strategie.ouvrir -image dossier -command {set path_strategie_n [tk_getOpenFile -title "Choix de la strat\u00E9gie" -initialdir "./descripteurs" -filetypes $type]
		if {[string length $path_strategie_n]} {
		set path_strategie $path_strategie_n}}
 

	button .w.caracteristique.piste.edit -image editeur -command {ScilabEval "scipad('$path_piste');"}
	button .w.caracteristique.robot.edit -image editeur -command {ScilabEval "scipad('$path_robot');"}
	button .w.caracteristique.strategie.edit -image editeur -command {ScilabEval "scipad('$path_strategie');"}

	pack .w.caracteristique.piste.etiqu .w.caracteristique.piste.label .w.caracteristique.piste.ouvrir .w.caracteristique.piste.edit -side left -anchor w
	pack .w.caracteristique.robot.etiqu .w.caracteristique.robot.label .w.caracteristique.robot.ouvrir .w.caracteristique.robot.edit -side left -anchor w
	pack .w.caracteristique.strategie.etiqu .w.caracteristique.strategie.label .w.caracteristique.strategie.ouvrir .w.caracteristique.strategie.edit -side left -anchor w
	
	button .w.caracteristique.antoine -width 60 -text "En savoir plus..." -command {tk_messageBox -icon info -type ok -message "D\u00E9velopp\u00E9 par A. Tauvel & N. Simond entre janvier 2008 et f\u00E9vrier 2009  pour les \u00E9tudiants de GEII Sarcelles. \n SciLab doit \u00EAtre install\u00E9 pour le calcul des trajectoires."}
	button .w.caracteristique.voir -width 60 -text "Voir les caract\u00E9ristiques statiques" -command {ScilabEval "exec('./affiche_carac.sci');"}
	button .w.caracteristique.lance.play -width 60 -text "Lancer la simulation" -command {ScilabEval "exec('./simulation.sci');"}

	pack .w.caracteristique.lance.play -side left  
		
	label .w.caracteristique.temps.aff -width 40 -justify right -text "Temps de parcours de la piste : "
	label .w.caracteristique.temps.aff_l -textvariable temps

	pack .w.caracteristique.temps.aff .w.caracteristique.temps.aff_l -side left	

	label .w.caracteristique.distance.aff -width 40 -justify right -text "Ecart moyen avec la piste : "
	label .w.caracteristique.distance.aff_l -textvariable distance

	pack .w.caracteristique.distance.aff .w.caracteristique.distance.aff_l -side left	

	pack .w.caracteristique.piste .w.caracteristique.robot .w.caracteristique.strategie -side top -pady 2 
	pack .w.caracteristique.antoine .w.caracteristique.voir .w.caracteristique.lance .w.caracteristique.temps .w.caracteristique.distance -side top -pady 5 

	frame .w.audessus

	label .w.audessus.bienvenue -font {Helvetica -18 bold} -text "Bienvenue sur le simulateur \n de robot GEII Sarcelles" 
	
	canvas .w.audessus.can -width 126 -height 60 
	image create photo img_logo -file ./images/logo.gif
	.w.audessus.can create image 63 30 -image img_logo

	pack .w.audessus.can .w.audessus.bienvenue -side left -padx 70
	pack .w.audessus .w.caracteristique -side top
