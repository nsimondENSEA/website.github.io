// A. TAUVEL & N. SIMOND
// Sim'bot ou comment se comporte un robot suiveur de ligne
// version 26/02/09
//-----------------------------------------------------------------------------
// fonction annexe qui recherche des doublons dans une liste (vecteur)
//-----------------------------------------------------------------------------
function [Liste,Col] = supprime_doublons(Vecteur)
    
n   = length(Vecteur)
if(n > 1)   then
    Liste       = sort(Vecteur);
    Diff        = Liste(1:n-1) - Liste(2:n);
    Col         = find(Diff == 0);
    Liste(Col)  = [];
else
    Liste   = Vecteur;
    Col     = [];
end

endfunction
